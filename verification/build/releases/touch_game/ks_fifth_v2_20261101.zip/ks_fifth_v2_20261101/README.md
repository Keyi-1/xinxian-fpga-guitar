# KS 五度和声 V2（用户已确认试听，2026-11-01）

本包位流来自用户原工程 `gowin/neo_guitar_touch_game/neo_guitar_touch_game.gprj` 的原 impl 正式综合、布局布线。使用 Gowin Programmer 选择本目录 `neo_guitar_touch_game_ks_fifth_v2.fs`；本次未自动烧录或打开实物串口，板上输出及启动仍待实测。

保持4独立声部、每声部8个物理模型状态、共32状态；实际两条并行 KS 运算通路配合 TDM 和流水线，内部100MHz、音频48kHz。约1.4983倍频五度模型拥有独立延迟/低通/DC/指针状态；五度主模型容量224字，八区域合计1024字/声部，不新增 BSRAM。音域覆盖现有D3～G5及颤音。主模型混合系数根音128、五度80。

完整 P&R/STA 通过，系统/音频/KS Fmax 为 50.641 / 19.371 / 103.143 MHz；实际要求50/12.288/100MHz，setup/hold/latch/未布通均0。[资源报告](resource_report.txt)、[时序报告](timing_report.html)、[哈希绑定验证](verification.json)、[源文件清单](source_manifest.json)。

关闭五度与此前成功版288256个 PCM 逐值一致；实际 PLL 四声部 TDM 比较55996个声部 PCM，无截止时间溢出；本次实际综合网表与完整 RTL 比较覆盖五度开/关、四路同时发声及独立拨弦。触控、ADC、按钮和声命令的寄存输出仅作明确登记的输入刺激；音频/频率/演奏事件结果未被强制。网表仿真无 SDF，另通过实际布线 STA。

试听：[根音单独→五度单独→两者合奏](root_fifth_together.wav)，[原关闭五度→新合奏](off_vs_new_mix.wav)。D3/A3/A4/G5，统一固定增益的真实 RTL KS 干声，非板上 DAC 录音；无分段归一化或软件合成。用户已确认推荐版听感。

本位流 SHA256：`48239256e8c700b0d2e147046880e9ffef06c023b7f536d2cdb20ae5c12b44ab`。

旧成功位流另保留于仓库 `build/ks_fifth/before/known_good_ks32.fs` 和固定发布 `build/releases/touch_game/ks_tdm_32_20261101/`，SHA256 `2d4700d60754a51d8e4c5fe19ddc50fb233ca0848c410352b01dd92555913c41`。本包不覆盖旧发布。`DESIGN.md` 是仓库设计记录，其中仓库相对链接请在原工作区访问。
