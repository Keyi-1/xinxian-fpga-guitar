# KS 五度 V2 + LCD 180°（2026-11-01）

在 Gowin Programmer 中选择 `neo_guitar_touch_game_ks_fifth_v2_lcd180.fs`。本位流来自原工程及原 impl，保留已确认 KS 推荐音色（根音/五度主系数128/80，4独立声部、32模型状态，两条并行运算通路+TDM，48kHz音频/100MHz内部计算）。整屏文字、游戏、频谱及曲线统一旋转180°，触控映射与远端保持原配置。

正式综合、布局布线、STA及当前综合网表对照通过；系统/音频/KS Fmax为 52.586 / 18.847 / 109.24 MHz，要求50/12.288/100MHz；setup/hold/latch/未布通/已测deadline均0。两条原PR1014警告计入实际STA。详见[验证](verification.json)、[资源](resource_report.txt)、[时序](timing_report.html)、[源清单](source_manifest.json)。

本位流SHA256：`523659582b19be709e70d8544cfd0db4920dc2708b36ac481df2d08c7ad63760`。此前未翻转KS V2固定发布仍保留于仓库 `build/releases/touch_game/ks_fifth_v2_20261101/`，SHA256 `48239256e8c700b0d2e147046880e9ffef06c023b7f536d2cdb20ae5c12b44ab`，可回退。

本次未烧录/访问实物串口/提交/推送，板上显示、触控、音频和启动仍待实测。`DESIGN.md` 是仓库记录，其中仓库相对链接需在原工作区访问。无SDF仿真，另通过完整实际布线STA。
