# 芯弦 LCD 180° 旋转位流

本包基于 JDY-23 正式版本，仅旋转 LCD 全部显示内容：上方对应 D，下方对应 A。

在 Gowin Programmer 中选择本目录的 `neo_guitar_touch_game_lcd_rotate_180.fs`，按你现有的下载方式使用。无需重新综合。此包不包含新手机 APK；JDY-23 原 APK 与上传协议继续使用。

位流 SHA256：`32bc37c33ccea5395239684743c6d394bb13bde2aa59d9c5d7b4d365afc9367d`。

Gowin V1.9.12.03，GW5AT-LV60PG484AC1/I0 Device B。完整综合、布局布线和最终 STA 已通过，系统/音频 Fmax 为 50.078/18.291 MHz，setup/hold/未布通网络为 0。仍有两条既有 PR1014 提示；系统时序余量较窄。

`evidence/` 保存本次实际综合、布线及时序报告；`verification.json` 绑定构建输入、实际网表与位流哈希；`functional_validation.json` 记录 LCD 专项仿真范围。尚未进行新位流的实物屏幕验收。

源码与说明：https://github.com/Keyi-1/xinxian-fpga-guitar/blob/master/docs/LCD_ROTATION_180.md
